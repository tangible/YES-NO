#pragma once
/*
#include "ofxSimpleGuiControl.h"
#include "ofxSimpleGuiTitle.h"

class ofxSimpleGuiOptionGroup  : public ofxSimpleGuiTitle {
public:
	int *value;
	
	
	ofxSimpleGuiOptionGroup(string name, int *value) : ofxSimpleGuiTitle(name) {
		controlType = "OptionGroup";
	}
};
*/